# Oro Design System

Reference for `oro-kit@0.3.0` and the [lavender René homepage](https://www.buildingoro.ca/).

Use the brand palette, typography, and documented React APIs when designing for Oro. The outfit conversation is a product example.

## Foundations

Explore the brand colors, typography, and layout values behind the lavender homepage.

### Brand colors

| Color | Value | CSS variable | Use |
| --- | --- | --- | --- |
| Plum | `#573969` | `--oro-color-cta` | Primary actions |
| Violet | `#8466b6` | `--oro-color-display` | Display emphasis |
| Lavender | `#cdbbe9` | `--oro-color-lavender` | Page wash and soft backgrounds |
| Deep plum | `#3a2646` | `--oro-color-deep-plum` | Ribbon background |
| Cream | `#fff9ed` | `--oro-color-cream` | Ribbon lettering and light artwork |

### Neutrals

| Color | Value | CSS variable | Use |
| --- | --- | --- | --- |
| Ink | `#332d46` | `--oro-color-ink` | Headlines and body text |
| White | `#ffffff` | `--oro-color-surface` | Page background and surfaces |
| Pale lavender | `#fcfbff` | `--oro-color-canvas` | Feature grid background |
| Black | `#000000` | `--oro-color-footer` | Footer background |

### Typography

Use Fraunces for display headings and DM Sans for body, controls, and labels. Use the supplied artwork for the Oro logo.

| Token | CSS variable | Value |
| --- | --- | --- |
| `font.family.body` | `--oro-font-family-body` | `'DM Sans', sans-serif` |
| `font.family.heading` | `--oro-font-family-heading` | `'Fraunces', Georgia, serif` |
| `font.family.wordmark` | `--oro-font-family-wordmark` | `'Outfit', sans-serif` |
| `font.weight.body` | `--oro-font-weight-body` | `400` |
| `font.weight.heading` | `--oro-font-weight-heading` | `400` |
| `font.weight.control` | `--oro-font-weight-control` | `500` |
| `font.weight.wordmark` | `--oro-font-weight-wordmark` | `500` |
| `font.weight.strong` | `--oro-font-weight-strong` | `700` |
| `type.display.size` | `--oro-type-display-size` | `4.75rem` |
| `type.display.lineHeight` | `--oro-type-display-line-height` | `1.075` |
| `type.display.tracking` | `--oro-type-display-tracking` | `-0.055em` |
| `type.displayMobile.size` | `--oro-type-display-mobile-size` | `3.375rem` |
| `type.displayMobile.lineHeight` | `--oro-type-display-mobile-line-height` | `1.075` |
| `type.displayMobile.tracking` | `--oro-type-display-mobile-tracking` | `-0.055em` |
| `type.title.size` | `--oro-type-title-size` | `2.875rem` |
| `type.title.lineHeight` | `--oro-type-title-line-height` | `1.12` |
| `type.title.tracking` | `--oro-type-title-tracking` | `-0.045em` |
| `type.section.size` | `--oro-type-section-size` | `2.125rem` |
| `type.section.lineHeight` | `--oro-type-section-line-height` | `1.12` |
| `type.section.tracking` | `--oro-type-section-tracking` | `-0.045em` |
| `type.card.size` | `--oro-type-card-size` | `2rem` |
| `type.card.lineHeight` | `--oro-type-card-line-height` | `1.15` |
| `type.card.tracking` | `--oro-type-card-tracking` | `-0.045em` |
| `type.subheading.size` | `--oro-type-subheading-size` | `1.125rem` |
| `type.subheading.lineHeight` | `--oro-type-subheading-line-height` | `1.4` |
| `type.subheading.tracking` | `--oro-type-subheading-tracking` | `-0.025em` |
| `type.body.size` | `--oro-type-body-size` | `1rem` |
| `type.body.lineHeight` | `--oro-type-body-line-height` | `1.6` |
| `type.body.tracking` | `--oro-type-body-tracking` | `0em` |
| `type.label.size` | `--oro-type-label-size` | `0.875rem` |
| `type.label.lineHeight` | `--oro-type-label-line-height` | `1.5` |
| `type.label.tracking` | `--oro-type-label-tracking` | `0em` |
| `type.support.size` | `--oro-type-support-size` | `0.75rem` |
| `type.support.lineHeight` | `--oro-type-support-line-height` | `1.8` |
| `type.support.tracking` | `--oro-type-support-tracking` | `0em` |
| `type.wordmark.size` | `--oro-type-wordmark-size` | `2.375rem` |
| `type.wordmark.lineHeight` | `--oro-type-wordmark-line-height` | `1` |
| `type.wordmark.tracking` | `--oro-type-wordmark-tracking` | `-0.085em` |
| `type.gridTitle.size` | `--oro-type-grid-title-size` | `clamp(2.1rem, 3.6vw, 3.4rem)` |
| `type.gridTitle.lineHeight` | `--oro-type-grid-title-line-height` | `1.08` |
| `type.gridTitle.tracking` | `--oro-type-grid-title-tracking` | `-0.025em` |
| `type.footerTitle.size` | `--oro-type-footer-title-size` | `clamp(2.5rem, 5vw, 4rem)` |
| `type.footerTitle.lineHeight` | `--oro-type-footer-title-line-height` | `1.06` |
| `type.footerTitle.tracking` | `--oro-type-footer-title-tracking` | `-0.045em` |
| `type.cta.size` | `--oro-type-cta-size` | `1.3rem` |
| `type.cta.lineHeight` | `--oro-type-cta-line-height` | `1.5` |
| `type.cta.tracking` | `--oro-type-cta-tracking` | `-0.01em` |

### Spacing and layout

The landing’s desktop conversation uses a pinned demonstration. The mobile layout stacks the copy, platform choice, and conversation in reading order.

| Token | CSS variable | Value |
| --- | --- | --- |
| `space.0` | `--oro-space-0` | `0` |
| `space.1` | `--oro-space-1` | `0.25rem` |
| `space.2` | `--oro-space-2` | `0.5rem` |
| `space.3` | `--oro-space-3` | `0.75rem` |
| `space.4` | `--oro-space-4` | `1rem` |
| `space.5` | `--oro-space-5` | `1.25rem` |
| `space.6` | `--oro-space-6` | `1.5rem` |
| `space.8` | `--oro-space-8` | `2rem` |
| `space.10` | `--oro-space-10` | `2.5rem` |
| `space.12` | `--oro-space-12` | `3rem` |
| `space.16` | `--oro-space-16` | `4rem` |
| `space.20` | `--oro-space-20` | `5rem` |
| `space.24` | `--oro-space-24` | `6rem` |
| `layout.contentMax` | `--oro-layout-content-max` | `1120px` |
| `layout.gutterDesktop` | `--oro-layout-gutter-desktop` | `48px` |
| `layout.gutterMobile` | `--oro-layout-gutter-mobile` | `24px` |
| `breakpoint.narrow` | `--oro-breakpoint-narrow` | `360px` |
| `breakpoint.mobile` | `--oro-breakpoint-mobile` | `650px` |
| `breakpoint.narrowLayout` | `--oro-breakpoint-narrow-layout` | `900px` |
| `breakpoint.desktopGrid` | `--oro-breakpoint-desktop-grid` | `1024px` |

### Surfaces and effects

| Token | CSS variable | Value |
| --- | --- | --- |
| `radius.field` | `--oro-radius-field` | `0.625rem` |
| `radius.card` | `--oro-radius-card` | `1rem` |
| `radius.pill` | `--oro-radius-pill` | `999px` |
| `border.width` | `--oro-border-width` | `1px` |
| `effect.lavenderWash` | `--oro-effect-lavender-wash` | `radial-gradient(ellipse at 4% 6%, var(--oro-color-wash-soft), transparent 58%), radial-gradient(ellipse at 94% 32%, var(--oro-color-glow), transparent 62%), radial-gradient(ellipse at 18% 100%, var(--oro-color-wash-soft), transparent 54%), linear-gradient(145deg, var(--oro-color-surface), var(--oro-color-surface) 48%, var(--oro-color-surface))` |
| `effect.lavenderWashMobile` | `--oro-effect-lavender-wash-mobile` | `radial-gradient(ellipse at 0% 0%, var(--oro-color-wash-soft), transparent 64%), radial-gradient(ellipse at 100% 75%, var(--oro-color-glow), transparent 70%), var(--oro-color-surface)` |
| `shadow.actionHover` | `--oro-shadow-action-hover` | `0 4px 12px #6c52ab14` |
| `shadow.cta` | `--oro-shadow-cta` | `0 16px 38px rgb(43 22 70 / 30%), 0 4px 12px rgb(43 22 70 / 16%), inset 0 1px 0 var(--oro-color-cta-outline)` |
| `shadow.ctaHover` | `--oro-shadow-cta-hover` | `0 20px 48px rgb(43 22 70 / 34%), 0 6px 16px rgb(43 22 70 / 18%), inset 0 1px 0 rgb(255 255 255 / 20%)` |
| `shadow.ctaSweep` | `--oro-shadow-cta-sweep` | `0 0 0 1px rgb(199 166 240 / 35%), 0 0 22px rgb(176 132 232 / 55%), 0 16px 38px rgb(43 22 70 / 30%), inset 0 0 18px rgb(214 186 255 / 45%)` |

### Motion

The homepage rotates its headline, reveals the conversation as you scroll, and moves the outfit gallery. Its reduced-motion layout presents the content in a static reading order.

| Token | CSS variable | Value |
| --- | --- | --- |
| `motion.duration` | `--oro-motion-duration` | `140ms` |
| `motion.easing` | `--oro-motion-easing` | `ease` |
| `motion.ctaStartAngle` | `--oro-motion-cta-start-angle` | `250deg` |
| `motion.ctaSweepDuration` | `--oro-motion-cta-sweep-duration` | `3.2s` |
| `motion.ctaSweepEasing` | `--oro-motion-cta-sweep-easing` | `linear` |
| `motion.ctaAngleTransition` | `--oro-motion-cta-angle-transition` | `600ms` |
| `motion.ctaTransformDuration` | `--oro-motion-cta-transform-duration` | `240ms` |
| `motion.ctaTransformEasing` | `--oro-motion-cta-transform-easing` | `cubic-bezier(.2, .7, .2, 1)` |
| `motion.ctaShadowDuration` | `--oro-motion-cta-shadow-duration` | `350ms` |
| `motion.headlineOpacityDuration` | `--oro-motion-headline-opacity-duration` | `450ms` |
| `motion.headlineTravelDuration` | `--oro-motion-headline-travel-duration` | `500ms` |
| `motion.headlineTravelEasing` | `--oro-motion-headline-travel-easing` | `cubic-bezier(.5, 0, 0, 1)` |

## Components

Try the React components in the browser, then copy the same imports into your project.

### CTA link

Use for navigation to a primary destination. Set appearance to compact, prominent, or floating.

```tsx
import { CtaLink } from 'oro-kit';

<CtaLink href="https://www.buildingoro.ca/" appearance="prominent">
  visit the oro waitlist
</CtaLink>
```

### Button

Use for actions on the current page. Choose primary, secondary, or tertiary emphasis. The native button supports keyboard activation and disabled state.

```tsx
import { Button } from 'oro-kit';

<Button type="button" onClick={save}>Save outfit</Button>
<Button variant="secondary" onClick={reset}>Reset</Button>
<Button variant="tertiary" disabled>Unavailable</Button>
```

### Text field

Give the field a visible label. Use hint for instructions and error to describe how to correct an invalid value.

```tsx
import { TextField } from 'oro-kit';

<TextField label="Where are you headed?" name="plan" />
<TextField label="Email" type="email" error="Enter a complete email address." />
```

### Card

Group related content into one surface. Choose plain for a neutral surface or soft for a lavender tint.

```tsx
import { Card, Heading, Text } from 'oro-kit';

<Card tone="soft">
  <Heading as="h4" variant="card">Weekend plans</Heading>
  <Text>Build an outfit around your favorite jeans.</Text>
</Card>
```

### Chip

Use a short label for a toggleable category or attribute. Control selection in the parent.

```tsx
import { Chip } from 'oro-kit';

<Chip selected={selected} onSelectedChange={setSelected}>
  From your closet
</Chip>
```

### Notice

Use success or error tone near the result it applies to. The component announces updates with status or alert semantics.

```tsx
import { Notice } from 'oro-kit';

<Notice title="Outfit saved">Find it in your saved looks.</Notice>
<Notice tone="error" title="Try again">The outfit could not be saved.</Notice>
```

### Heading & text

Choose a heading level that follows the page outline. Use text for the supporting copy.

```tsx
import { Heading, Text } from 'oro-kit';

<Heading as="h4" variant="section">your next outfit</Heading>
<Text muted>One idea to get you out the door.</Text>
```

### Conversation options

Switch between two presentations of the same conversation. Supply a group label and a controlled selected value.

```tsx
import { ConversationOptions } from 'oro-kit';

<ConversationOptions
  label="Messaging platform"
  options={[
    { value: 'imessage', label: 'iMessage' },
    { value: 'whatsapp', label: 'WhatsApp' },
  ]}
  value={channel}
  onValueChange={setChannel}
/>
```

### Message bubble

Use direction to identify the side of the conversation. Provide the speaker for assistive technology and use media for image messages.

```tsx
import { MessageBubble } from 'oro-kit';

<MessageBubble direction="sent" sender="You" meta="8:03">
  swap the shorts for cargos
</MessageBubble>
```

## Patterns

Reusable compositions from the homepage’s product demonstration and closing invitation.

### Outfit conversation

Pair a short request and response with a visual result. Keep the sender and image description meaningful when changing the example.

```tsx
import { MessageBubble } from 'oro-kit';

<ol aria-label="Sample outfit conversation">
  <li><MessageBubble sender="You" direction="sent">swap the shorts for cargos</MessageBubble></li>
  <li><MessageBubble sender="Oro">okay! here’s another option.</MessageBubble></li>
  <li><MessageBubble sender="Oro" media>
    <img src={outfitImage} alt="Two collages showing shorts swapped for cargo pants" />
  </MessageBubble></li>
</ol>
```

### Closing invitation

Keep a short headline, one line of supporting copy, and a single action. Use the lavender wash to echo the opening section.

```tsx
import { CtaLink, Heading, Text } from 'oro-kit';
import { tokens } from 'oro-kit/tokens';

<section style={{ background: tokens.effect.lavenderWash }}>
  <Heading as="h2" variant="title">save your spot.</Heading>
  <Text>one text. no download. she’s all yours.</Text>
  <CtaLink href="https://www.buildingoro.ca/" appearance="prominent">See the live waitlist</CtaLink>
</section>
```

## Brand assets

Download Oro’s marks, mascot art, product examples, and creative references.

[Download the brand kit ZIP](./brand/oro-brand-kit.zip)

- [Oro header lockup](./brand/oro-wordmark.png) (PNG) — Dark wordmark with mascot from the landing header. Place it on a light field.
- [Oro footer wordmark](./brand/oro-footer-wordmark.png) (PNG) — Cream wordmark from the dark landing footer. Preserve its aspect ratio and use a dark field.
- [Oro favicon](./brand/oro-favicon.webp) (WebP) — The browser tab icon from the landing site.
- [Message icon](./brand/message-icon.svg) (SVG) — Editable path from the landing action. It inherits the surrounding text color when used inline.
- [Oro taking notes](./brand/oro-mascot-jotting.png) (PNG) — Transparent mascot artwork from the product feature and conversation avatar.
- [Waving mascot body](./brand/oro-mascot.png) (PNG) — Transparent body layer from the headline. The live animation renders the eyes separately.
- [Outfit iteration](./brand/outfit-iteration.png) (PNG) — Scripted before-and-after example showing a swap from shorts to cargo pants.
- [Brunch outfit](./brand/brunch-outfit.webp) (WebP) — Clothing collage from the sample conversation. The small mark baked into it belongs to the example artwork.
- [Color and type reference](./brand/colors-and-type.md) (Markdown) — Current package color values, font access links, and type sizes.
- [Motion reference](./brand/motion.md) (Markdown) — Timing, easing, and reduced-motion behavior observed on the landing page.
- [CTA motion sample](./brand/motion.html) (HTML) — Open the copy inside the ZIP in your browser to preview the animated CTA without a network connection.
- [Mascot mark source copy](./brand/drive/logos/Copy%20of%20oro_logo_mascot_only.png) (PNG) — A byte-identical copy included in the supplied Drive folder.
- [Mascot mark](./brand/drive/logos/oro_logo_mascot_only.png) (PNG) — The mascot used as a standalone mark.
- [Black wordmark](./brand/drive/logos/oro_logo_wordmark_black.png) (PNG) — Black treatment supplied in the source artwork.
- [Full Oro lockup](./brand/drive/logos/oro_logo_wordmark_full.png) (PNG) — The mascot and wordmark supplied as a complete lockup.
- [Gold wordmark](./brand/drive/logos/oro_logo_wordmark_gold.png) (PNG) — Gold treatment supplied in the source artwork.
- [Standalone wordmark](./brand/drive/logos/oro_logo_wordmark_only.png) (PNG) — The lettering without the mascot.
- [Purple wordmark](./brand/drive/logos/oro_logo_wordmark_purple.png) (PNG) — Purple treatment supplied in the source artwork.
- [Oro amazed](./brand/drive/mascot/amazed.png) (PNG) — Original mascot illustration.
- [Oro touched](./brand/drive/mascot/aww.png) (PNG) — Original mascot illustration.
- [Oro cheeky](./brand/drive/mascot/cheeky.png) (PNG) — Original mascot illustration.
- [Oro jotting](./brand/drive/mascot/jotting.png) (PNG) — Original mascot illustration.
- [Oro default pose](./brand/drive/mascot/oro_default.png) (PNG) — Original mascot illustration.
- [Oro waving](./brand/drive/mascot/oro_hi.png) (PNG) — Original mascot illustration.
- [Oro cheering](./brand/drive/mascot/oro_hurray.png) (PNG) — Original mascot illustration.
- [Oro looking back](./brand/drive/mascot/oro_looking_back.png) (PNG) — Original mascot illustration.
- [Oro sad](./brand/drive/mascot/oro_sad.png) (PNG) — Original mascot illustration.
- [Oro sleeping](./brand/drive/mascot/oro_sleeping.png) (PNG) — Original mascot illustration.
- [Oro texting](./brand/drive/mascot/oro_texting.png) (PNG) — Original mascot illustration.
- [Oro giving a thumbs-up](./brand/drive/mascot/oro_thumbs_up.png) (PNG) — Original mascot illustration.
- [Oro waking up](./brand/drive/mascot/oro_waking.png) (PNG) — Original mascot illustration.
- [Oro shocked](./brand/drive/mascot/shocked.png) (PNG) — Original mascot illustration.
- [Oro thinking](./brand/drive/mascot/thinking.png) (PNG) — Original mascot illustration.
- [Oro waving without accessories](./brand/drive/mascot-layers/oro_hi.png) (PNG) — Isolated mascot layer for compositing.
- [Oro cheering without accessories](./brand/drive/mascot-layers/oro_hurray.png) (PNG) — Isolated mascot layer for compositing.
- [Oro looking back without accessories](./brand/drive/mascot-layers/oro_looking_back.png) (PNG) — Isolated mascot layer for compositing.
- [Oro texting without accessories](./brand/drive/mascot-layers/oro_texting.png) (PNG) — Isolated mascot layer for compositing.
- [Oro giving a thumbs-up without accessories](./brand/drive/mascot-layers/oro_thumbs_up.png) (PNG) — Isolated mascot layer for compositing.
- [Dash accent 2 source](./brand/drive/mascot-accents/dashes_2.kra) (Krita (KRA)) — Editable Krita project for the accent.
- [Dash accent 2](./brand/drive/mascot-accents/dashes_2.png) (PNG) — Standalone accent artwork for mascot compositions.
- [Dash accent 3 source](./brand/drive/mascot-accents/dashes_3.kra) (Krita (KRA)) — Editable Krita project for the accent.
- [Dash accent 3](./brand/drive/mascot-accents/dashes_3.png) (PNG) — Standalone accent artwork for mascot compositions.
- [Star accent](./brand/drive/mascot-accents/star.png) (PNG) — Standalone accent artwork for mascot compositions.
- [Amazed polaroid](./brand/drive/polaroids/amazed.png) (PNG) — Framed mascot illustration from the supplied polaroid set.
- [Touched polaroid](./brand/drive/polaroids/aww.png) (PNG) — Framed mascot illustration from the supplied polaroid set.
- [Cheeky polaroid](./brand/drive/polaroids/cheeky.png) (PNG) — Framed mascot illustration from the supplied polaroid set.
- [Jotting polaroid](./brand/drive/polaroids/jotting.png) (PNG) — Framed mascot illustration from the supplied polaroid set.
- [Shocked polaroid](./brand/drive/polaroids/shocked.png) (PNG) — Framed mascot illustration from the supplied polaroid set.
- [Thinking polaroid](./brand/drive/polaroids/thinking.png) (PNG) — Framed mascot illustration from the supplied polaroid set.

Relative asset paths resolve from the design-system site. Attach the relevant image or asset file when sharing this reference with an AI tool.

## Developer guide

Install the package in a React project and load the shared styles once at your app entry point.

### Install this revision

Use the packed tarball while this revision awaits publication on npm.

```sh
pnpm pack --pack-destination /tmp
# From the consumer checkout
npm install /tmp/oro-kit-0.3.0.tgz
```

### Import fonts and styles

Load the package CSS once at your app entry point.

```tsx
import 'oro-kit/fonts.css';
import 'oro-kit/styles.css';
```

### Use a component and a token

Use the documented exports with the shared CSS loaded.

```tsx
import { CtaLink } from 'oro-kit';
import { tokens } from 'oro-kit/tokens';

<section style={{ background: tokens.effect.lavenderWash }}>
  <CtaLink href="https://www.buildingoro.ca/" appearance="prominent">
    visit the oro waitlist
  </CtaLink>
</section>
```

### Develop locally

Run pnpm docs:build for the static site. The brand-kit build uses the system zip utility.

```sh
pnpm install --frozen-lockfile
pnpm check
pnpm docs:dev
```
