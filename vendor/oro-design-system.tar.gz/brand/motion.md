# Motion reference

The examples below come from [the lavender René landing page](https://www.askoro.now/).

| On the page | Timing and behavior | Reduced motion |
| --- | --- | --- |
| Hero headline | The typed introduction advances in 34 ms steps after an 80 ms lead-in. After it appears, the emphasized phrase cycles every 2.2 seconds. Opacity and blur transition in 450 ms, with a 500 ms vertical shift on `cubic-bezier(0.5, 0, 0, 1)`. | The first phrase stays visible. |
| Waving mascot | Room opens over 480 ms after 1.25 seconds. The 620 ms entrance begins at 1.65 seconds and overshoots scale before settling. Blinks repeat on a 4.6 second loop after 2.8 seconds. | The mascot holds still. |
| Hero and footer actions | The lavender edge makes one 360° sweep every 3.2 seconds, linear, during the active effect. | The edge holds its position. |
| Conversation | iMessage bubbles enter in 420 ms on `cubic-bezier(.2, .9, .3, 1.25)`. WhatsApp bubbles use 380 ms on `cubic-bezier(.2, .9, .3, 1.2)`. | The selected conversation displays all its messages without animated entrances. |

The headline and CTA effects are implemented in `src/designer-theme.css` and `src/components/home/DesignerHeadline.jsx`. The conversation timings are in `src/components/home/DesignerHome.css`.
