# Oro brand kit

This kit accompanies the lavender René design on [askoro.now](https://www.askoro.now/). Unzip it to browse the files without installing development tools.

- Use the dark header lockup on light backgrounds and the cream wordmark on dark backgrounds. Keep their aspect ratios. The PNGs preserve transparency for video and layout tools. The WebPs preserve the files served by the landing site.
- Use the jotting mascot as standalone artwork. The waving mascot body is a layer from the animated headline with eyes drawn separately by the website.
- The outfit visuals are examples from the public product demonstration. Use them to show the styling flow. The iteration image shows how Oro responds when someone asks to swap one garment.
- Find the supplied logo, mascot, accent, and polaroid artwork in `drive/`, including editable Krita accents. `drive-sources.md` links each file back to its Google Drive original.
- Start with `colors-and-type.md` for the palette, type values, and links to desktop fonts. The bundled Latin WOFF2 files include their SIL Open Font Licenses.
- Open `motion.html` in a browser for an offline CTA sample. Use `motion.md` for the timings and a link to see the other motion on the landing page.

The wordmarks are supplied as transparent raster files, and the message icon is supplied as an editable SVG. Editable logo artwork and an editable motion project were unavailable in the landing sources.
