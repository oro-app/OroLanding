# Oro color and type

Values from oro-kit 0.3.0.

## Color

### Brand colors

| Color | Value | CSS variable | Use |
| --- | --- | --- | --- |
| Plum | `#573969` | `--oro-color-cta` | Primary actions |
| Violet | `#8466b6` | `--oro-color-display` | Display emphasis |
| Lavender | `#cdbbe9` | `--oro-color-lavender` | Page wash and soft backgrounds |
| Deep plum | `#3a2646` | `--oro-color-deep-plum` | Ribbon background |
| Cream | `#fff9ed` | `--oro-color-cream` | Ribbon lettering and light artwork |

### Neutrals

| Color | Value | CSS variable | Use |
| --- | --- | --- | --- |
| Ink | `#332d46` | `--oro-color-ink` | Headlines and body text |
| White | `#ffffff` | `--oro-color-surface` | Page background and surfaces |
| Pale lavender | `#fcfbff` | `--oro-color-canvas` | Feature grid background |
| Black | `#000000` | `--oro-color-footer` | Footer background |

## Typography

| Family | Weight | Use |
| --- | --- | --- |
| [Fraunces](https://fonts.google.com/specimen/Fraunces) | 400 regular and italic | Headings and emphasis |
| [DM Sans](https://fonts.google.com/specimen/DM+Sans) | 400 regular, 500 medium, 700 bold | Body, labels and actions |
| [Outfit](https://fonts.google.com/specimen/Outfit) | 500 medium | Text treatment for the existing wordmark |

The landing browser synthesizes the bold action weight from the bundled DM Sans range. Conversation previews use the platform system sans-serif.

| Role | Size | Line height | Tracking |
| --- | --- | --- | --- |
| display | 4.75rem | 1.075 | -0.055em |
| displayMobile | 3.375rem | 1.075 | -0.055em |
| title | 2.875rem | 1.12 | -0.045em |
| section | 2.125rem | 1.12 | -0.045em |
| card | 2rem | 1.15 | -0.045em |
| subheading | 1.125rem | 1.4 | -0.025em |
| body | 1rem | 1.6 | 0em |
| label | 0.875rem | 1.5 | 0em |
| support | 0.75rem | 1.8 | 0em |
| wordmark | 2.375rem | 1 | -0.085em |
| gridTitle | clamp(2.1rem, 3.6vw, 3.4rem) | 1.08 | -0.025em |
| footerTitle | clamp(2.5rem, 5vw, 4rem) | 1.06 | -0.045em |
| cta | 1.3rem | 1.5 | -0.01em |
| conversationOption | 0.95rem | 1 | normal |

Use the linked desktop fonts in design or video tools. The Latin WOFF2s and their SIL Open Font Licenses accompany the offline browser sample.
