# Lavender René foundations

Visual reference confirmed for this rebuild: [buildingoro.ca](https://www.buildingoro.ca/). The live homepage was examined at 1440 × 900 and 390 × 844, including keyboard interaction and CTA motion. The release source is the René design on [OroLanding main](https://github.com/oro-app/OroLanding/commit/46c62bd16f50a4446f96f7ecf79f0500e83e8965). The earlier local René worktree is useful for CSS and asset provenance. The current live campaign uses a text waitlist.

**Observed** values come directly from the homepage. **Normalized** rules consolidate equivalent usage. **Added** rules fill a state or reusable API needed by a consumer. Exact token values are in `src/tokens.ts` and in the rendered foundations guide.

| Decision | Value or rule | Landing evidence | Classification |
| --- | --- | --- | --- |
| Canvas and wash | White base, lavender `#cdbbe9` at layered opacities. Desktop and mobile use separate radial layouts. | `src/designer-theme.css` and `src/brand-background.css` | Observed |
| Pale canvas and ink | `#fcfbff` on the outfit grid and `#332d46` primary ink. `#71637f` for muted reading copy. | `src/components/home/DesignerHome.css`, homepage computed CSS | Observed |
| Display emphasis and footer | `#8466b6` rotating display text, dark plum footer with cream mark and copy. | `src/designer-theme.css`, footer in homepage | Observed |
| Semantic colors | Reused color values expressed through ink, surface, action, display, border, and conversation roles. | `src/tokens.ts` consolidates the existing page roles | Normalized |
| Typography | Fraunces Regular 400 for live display, DM Sans for body and controls, Outfit for wordmark typography. Use the artwork when placing the official mark. | Live computed fonts, `src/serif-headings.css`, `src/site.css`, and `oro-kit/fonts.css` | Observed |
| Type hierarchy | Live hero tracking `-0.055em` and section heading tracking `-0.025em`. Responsive sizes use clamps and the small-screen overrides. | `#home-title` and homepage section headings, `src/components/home/DesignerHome.css` | Observed |
| Layout | Landing content frame up to 1120px with 48px and 24px gutters. Narrow screens stack the conversation and feature sections. | `src/components/home/DesignerHome.css` | Observed |
| CTA | Compact header, prominent hero and closer, and floating mobile placement. Prominent plum fill `#573969` with a lavender conic border. | `HomeCta` and `src/designer-theme.css` | Observed |
| CTA implementation | One anchor component owns the common appearance and native focus behavior. Consumers supply URL, label, icon, decoration and analytics. | Repeated homepage CTA markup and link variants | Normalized |
| CTA motion | A 3.2s border cycle on interaction, a 350ms shadow transition and 240ms movement. Reduced motion disables the sweep. | `oroCtaSpin` and reduced-motion rules in `src/designer-theme.css` | Observed |
| Campaign motion | Headline rotates every 2.2s. Phone playback and outfit gallery respond to scroll. Reduced motion keeps the first phrase and presents the full conversation and features in reading order. | `DesignerHeadline.jsx`, `useDesignerChat.js`, `DesignerHome.css` | Observed |
| Conversation | Labeled iMessage and WhatsApp choices, sent and received styling, sender, timestamps and outfit media. | `DesignerChat.jsx` and `DesignerHome.css` | Observed |
| Component focus and field states | Visible accent ring for light surfaces, stronger form field border and placeholder contrast. Existing controls retain their native form behavior. | Landing keyboard checks and retained form consumers | Added |
| Imagery | Header and footer lockups, mascot art, messaging icon, clothing collages and before-and-after styling demo. | `public/oro-logo/`, `public/oro-hi/`, `src/assets/demos/` | Observed |

The documentation’s wider canvas, asset gallery, and code copy controls are site layout and tooling choices. The landing remains responsible for campaign copy, conversation playback, links, and analytics. Earlier Halo swatches and prototype rules belong to Git history.

The downloadable brand kit uses existing artwork with reusable PNG exports, the original source formats where available, and the redistributable OFL font files and notices. Customer imagery, editable campaign projects, and unconfirmed marks are absent from the kit. No current Figma library was required for the rebuild.
